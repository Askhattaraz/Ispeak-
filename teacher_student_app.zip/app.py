from flask import Flask, render_template, request, redirect, url_for, session
from models import db, User, Group, Student
from flask_migrate import Migrate

app = Flask(__name__)
app.secret_key = "secret_key"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///app.db"
db.init_app(app)
migrate = Migrate(app, db)

@app.route("/")
def index():
    if "user_id" not in session:
        return redirect(url_for("login"))
    user = User.query.get(session["user_id"])
    if user.role == "teacher":
        groups = Group.query.filter_by(teacher_id=user.id).all()
        return render_template("teacher_dashboard.html", groups=groups, user=user)
    elif user.role == "admin":
        teachers = User.query.filter_by(role="teacher").all()
        groups = Group.query.all()
        return render_template("admin_dashboard.html", teachers=teachers, groups=groups, user=user)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        user = User.query.filter_by(username=username).first()
        if user:
            session["user_id"] = user.id
            return redirect(url_for("index"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("user_id", None)
    return redirect(url_for("login"))

@app.route("/create_group", methods=["POST"])
def create_group():
    if "user_id" not in session:
        return redirect(url_for("login"))
    user = User.query.get(session["user_id"])
    if user.role != "admin":
        return "Access Denied"
    group_name = request.form["group_name"]
    teacher_id = request.form.get("teacher_id")
    group = Group(name=group_name, teacher_id=teacher_id)
    db.session.add(group)
    db.session.commit()
    return redirect(url_for("index"))

@app.route("/add_student/<int:group_id>", methods=["POST"])
def add_student(group_id):
    if "user_id" not in session:
        return redirect(url_for("login"))
    user = User.query.get(session["user_id"])
    if user.role not in ["admin", "teacher"]:
        return "Access Denied"
    name = request.form["name"]
    student = Student(name=name, group_id=group_id)
    db.session.add(student)
    db.session.commit()
    return redirect(url_for("index"))

@app.route("/move_student/<int:student_id>", methods=["POST"])
def move_student(student_id):
    if "user_id" not in session:
        return redirect(url_for("login"))
    user = User.query.get(session["user_id"])
    if user.role != "admin":
        return "Access Denied"
    new_group_id = request.form["new_group_id"]
    student = Student.query.get(student_id)
    student.group_id = new_group_id
    db.session.commit()
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
