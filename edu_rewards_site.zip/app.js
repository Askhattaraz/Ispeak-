const users = {
  missveronika: { password: "Kazakhstan08", role: "admin" },
  teacher1: { password: "teacher1", role: "teacher", id: "teacher1" },
  teacher2: { password: "teacher2", role: "teacher", id: "teacher2" },
  teacher3: { password: "teacher3", role: "teacher", id: "teacher3" }
};

function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const user = users[username];

  if (user && user.password === password) {
    localStorage.setItem("user", JSON.stringify({ username, ...user }));
    window.location.href = "dashboard.html";
  } else {
    document.getElementById("error-message").textContent = "Неверный логин или пароль.";
  }
}

function guestLogin() {
  localStorage.setItem("user", JSON.stringify({ username: "guest", role: "guest" }));
  window.location.href = "dashboard.html";
}

function logout() {
  localStorage.removeItem("user");
  window.location.href = "index.html";
}

function renderDashboard() {
  const user = JSON.parse(localStorage.getItem("user"));
  if (!user) window.location.href = "index.html";

  document.getElementById("userRole").textContent = user.username;

  const main = document.getElementById("main-content");
  if (user.role === "guest") {
    main.innerHTML = "<p>Вы вошли как ученик. Доступ только для просмотра.</p>";
    return;
  }

  let html = "<h2>Группы и ученики</h2>";
  html += "<p>Тут будет реализация управления группами, учениками и баллами.</p>";
  if (user.role === "admin") {
    html += "<p>У вас есть возможность перемещать учеников между группами и учителями, а также выборочно очищать историю.</p>";
  }
  main.innerHTML = html;
}

if (window.location.pathname.includes("dashboard.html")) {
  renderDashboard();
}