
const users = {
    missveronika: 'Kazakhstan08',
    teacher1: 'teacher1',
    teacher2: 'teacher2',
    teacher3: 'teacher3'
};
let currentUser = null;

function login() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    if (users[username] && users[username] === password) {
        currentUser = username;
        showMain();
    } else {
        document.getElementById('login-error').textContent = 'Неверный логин или пароль';
    }
}

function guestLogin() {
    currentUser = 'guest';
    showMain();
}

function logout() {
    currentUser = null;
    document.getElementById('main-container').classList.add('hidden');
    document.getElementById('login-container').classList.remove('hidden');
}

function showMain() {
    document.getElementById('login-container').classList.add('hidden');
    document.getElementById('main-container').classList.remove('hidden');
    document.getElementById('welcome').textContent =
        currentUser === 'guest' ? 'Добро пожаловать, гость' : `Добро пожаловать, ${currentUser}`;
    document.getElementById('content').innerHTML = generateContent();
}

function generateContent() {
    if (currentUser === 'guest') {
        return '<p>Вы вошли как гость. Доступен только просмотр.</p>';
    }
    if (currentUser === 'missveronika') {
        return '<p>Панель директора. Здесь можно управлять всеми группами и учениками.</p>';
    }
    return `<p>Панель учителя: ${currentUser}. Здесь отображаются только ваши группы и ученики.</p>`;
}
