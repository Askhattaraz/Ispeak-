
from flask import Flask, render_template, request, redirect, session, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'

def get_db():
    conn = sqlite3.connect('data.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    if 'user' in session:
        role = session['role']
        if role == 'director' or role == 'teacher':
            return redirect('/dashboard')
        elif role == 'guest' or role == 'student':
            return redirect('/viewer')
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    db.close()
    if user and check_password_hash(user['password_hash'], password):
        session['user'] = user['username']
        session['role'] = user['role']
        return redirect('/')
    return 'Неверный логин или пароль'

@app.route('/dashboard')
def dashboard():
    if 'user' not in session or session['role'] not in ['director', 'teacher']:
        return redirect('/')
    return render_template('dashboard.html', role=session['role'], user=session['user'])

@app.route('/viewer')
def viewer():
    return render_template('viewer.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')
